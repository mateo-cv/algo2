#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "dijkstra.h"
#include "set.h"

int main(int argc, char *argv[])
{
    if (argc < 2) {
        printf("Debe ingresar el mapa de las ciudades usando:\n ./dijkstra input/example_graph_1.in\n");
        printf("El archivo debe contener primero la cantidad total de ciudades,\n");
        printf("y luego una descripcion del costo de viaje entre cada par de ciudades\n");
        printf("o # si no es posible realizar el viaje entre dichas ciudades\n");
        printf("en un formato de grilla, donde el costo de viajar de la ciudad i a la ciudad j\n");
        printf("se encuentre en la fila i y columna j\n");
        exit(EXIT_FAILURE);
    }
    graph_t graph = graph_from_file(argv[1]);
    int size = graph_max_size(graph);
    cost_t l = 0;
    printf("Ingrese la cantidad de nafta disponible: ");
    scanf("%d",&l);
    assert(l >= 0);
    unsigned int n = 0;
    printf("Ingrese la cantidad de ciudades que le gustaria visitar (al menos una): ");
    scanf("%u",&n);
    assert( n > 0 && n <= graph_max_size(graph));
    set s = set_empty();
    printf("Ingrese las %u ciudades diferentes que le gustaria visitar (Arrancando desde 0): ", n);
    for (unsigned int i = 0; i < n; i++) {
    	type_elem e;
        scanf("%d", &e);
        assert(e >= 0 && e < size);
        assert(!set_member(e, s));
        s = set_add(s, e);
    }
    vertex_t init = 0;
    printf("Ingrese la ciudad desde la cual iniciara el viaje: ");
    scanf("%u",&init);
    cost_t *costs = dijkstra(graph, init);
    set destination = set_empty();
    set s_aux = set_copy(s);
    while(!set_is_empty(s_aux)){
    	type_elem e = set_get(s_aux);
    	if(cost_le(costs[e],l)){
    		destination = set_add(destination, e);
    	}
    	s_aux = set_elim(s_aux, e);
    }
    s_aux = set_destroy(s_aux);
    if(set_is_empty(destination)){
    	printf("No es posible visitar ninguna de las ciudades seleccionadas con la cantidad de nafta disponible\n");
    }else{
    	unsigned int card = set_cardinal(destination);
	    printf("Las %u ciudades alcanzables con la cantidad de nafta disponible son:\n", card);
		set dest_aux = set_copy(destination);
	    while(!set_is_empty(dest_aux)){
	    	type_elem e = set_get(dest_aux);
	    	printf("La ciudad %d es alcanzable utilizando ", e);
			cost_print(costs[e]);
			printf(" litros de nafta\n");
	    	dest_aux = set_elim(dest_aux, e);
	    }
	    dest_aux = set_destroy(dest_aux);	
    }
    free(costs);
    graph = graph_destroy(graph);
}
