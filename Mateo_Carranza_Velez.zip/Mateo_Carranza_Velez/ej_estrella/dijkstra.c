#include <assert.h>
#include <stdlib.h>
#include <limits.h>

#include "cost.h"
#include "graph.h"
#include "set.h"

//devuelve el vertice del conjunto con menor distancia, si ningun vertice del conjunto es alcanzable devuelve UINT_MAX
vertex_t choose(cost_t *d, set s){
	assert(!set_is_empty(s));
	set s_aux = set_copy(s);
	cost_t min_value = cost_inf();
	vertex_t min_vertex = UINT_MAX;
	while(!set_is_empty(s_aux)){
		type_elem e = set_get(s_aux);
		if(cost_lt(d[e], min_value)){
			min_value = d[e];
			min_vertex = e;
		}
		s_aux = set_elim(s_aux, e);
	}
	s_aux = set_destroy(s_aux);
	return min_vertex;
}

cost_t *dijkstra(graph_t graph, vertex_t init)
{
	cost_t *d= calloc(graph_max_size(graph), sizeof(cost_t));
	vertex_t c = 0;
	set s = set_empty();
	for(unsigned int i = 0; i < graph_max_size(graph) ; i++){
		s = set_add(s, i);
	}
	s = set_elim(s, init);
	for(unsigned int i = 0; i < graph_max_size(graph) ; i++){
		d[i] = graph_get_cost(graph, init, i);
	}
	bool b = true;
	while(!set_is_empty(s) && b){
		c = choose(d, s);
		if(c != UINT_MAX){
			s = set_elim(s, c);
			set s_aux = set_copy(s);
			while(!set_is_empty(s_aux)){
				type_elem e = set_get(s_aux);
				if(cost_lt(cost_sum(d[c], graph_get_cost(graph, c, e)), d[e])){
					d[e] = cost_sum(d[c], graph_get_cost(graph, c, e));
				}
				s_aux = set_elim(s_aux, e);
			}
			s_aux = set_destroy(s_aux);
		}else{
			b = false;
		}
	}
	s = set_destroy(s);
	return d;
}
